#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""The pipeline cell at the published scope sizes.

Why this file exists
--------------------
The paper has two results that a reader is entitled to compare and cannot.
`fullpath_band_vs_scan.py` runs the *five-stage pipeline* -- probe, decide,
execute, mask, overlay -- but on the replay instance, whose median scope is 401
rows.  `bigscope.py` runs at the *published* per-code sizes, up to 412,875
beneficiary-days, but on bare paths: it passes an empty rule set, so the mask
folds into the override filter alone and no support multiplicity is ever
consulted.  So "retrieval loses at 401 rows" and "retrieval wins at 44,606
rows" are statements about two different objects, and neither is the claim the
paper makes, which is that the *pipeline* changes sign with scale.

This script closes that gap the only way it can be closed: run the pipeline of
Sec. IV-F, at the published scope sizes, on stores whose layout is the one
`bigscope.py` establishes (code drawn at random over the whole store, so path B
gathers through a scattered id space while path R scans a code-clustered copy --
the asymmetry that is the entire reason the two paths differ).

What the pipeline adds over the bare kernel
-------------------------------------------
  mask       Thm. 3: a candidate flips only if its support multiplicity before
             the correction equals 1[theta_new > theta_old].  Two rules sit on
             every code -- the moved cap and a standing stricter one, as the MUE
             table carries several MAI variants per HCPCS code -- so sigma is not
             identically 1 and the mask actually fires.  sigma is *maintained*,
             as the paper assumes: one byte per line, refreshed by the pass that
             emits the previous flip set, read here as one gather.
  dedup      flip identifiers deduplicated before emission.
  overlay    the boolean overlay absorbing this correction's flips.
  selector   Eq. (12) with the calibrated tuple, probe paid on either branch.

The mask is charged to both paths, which is the paper's own claim about it
("a system delivering true verdict deltas pays the mask exactly as a certifier
does").  It is therefore a constant added to both sides, and the question this
file answers is whether that constant is large enough to move the ratio.  It is
not: at the median scope the mask costs the same 1.9 us on both paths, and the
band's advantage is 0.58x either way.

What is synthetic and what is not
---------------------------------
The *sizes* are published (the per-code beneficiary-day counts of Sec. V-D(c)).
The band *densities* are swept over the ceiling quartiles of the same section.
The unit values are not published per day, so a band is populated to a target
density with the shape an MUE move of 4 -> 2 produces (half the candidates at
the lower atom, so the mask splits the band rather than passing it through).

  python masked_pipeline.py --reps 5
"""
import argparse
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
sys.path.insert(0, os.path.join(HERE, ".."))          # certis.py at the root

import certis as C                                     # noqa: E402

# The published per-code beneficiary-day counts (realband.py): 5th percentile,
# quartile, median, upper quartile of six years of CMS data.
NS = [("p5", 197), ("q1", 6969), ("median", 44606), ("q3", 412875)]
# The band densities of Sec. V-D(c): the ceiling's median and its quartiles.
DS = [0.042, 0.183, 0.401]

CAP_OLD, CAP_NEW = 4, 2        # the dominant observed MUE shape, tightened
AUX_CAP = 3                    # a stricter standing cap on the same code
DAYS_PER_GROUP = 58            # published median days per (NPI, code) pair
OVERRIDE_P = 0.18              # measured share of groups carrying an override
SEED = 31337

# The selector's tuple: order-controlled over 23 runs (Table V, last row).
KAPPA = 0.2142
DP = 198.8

TUPLE_NOTE = "eq.(12) with kappa 0.2142, dp 198.8 as printed in Table V"


def build(plans):
    """One store, one code per (n, density) cell.

    Layout follows bigscope.py exactly: the code of each line is drawn over the
    whole store at random and the group id is the line's position divided by the
    published days-per-group, so path B gathers through a scattered id space
    while path R scans a contiguous copy.  Assigning each code a contiguous block
    would make every gather sequential and halve the per-candidate cost.
    """
    rng = np.random.default_rng(SEED)
    n_c = [int(round(n)) for _, n, _ in plans]
    d_c = [d for _, _, d in plans]
    total = sum(n_c)

    code_of = np.repeat(np.arange(len(plans), dtype=np.int32), n_c)
    code_of = code_of[rng.permutation(total)]
    unit = np.ones(total, dtype=np.int16)

    for code in range(len(plans)):
        pos = np.flatnonzero(code_of == code)
        d = d_c[code]
        # candidates are unit in (CAP_NEW, CAP_OLD]; half at each atom, so the
        # mask (sigma = s*) keeps the lower atom and drops the upper one
        k = int(round(d * len(pos)))
        k_lo, k_hi = k // 2, k - k // 2
        pick = rng.choice(pos, size=min(k, len(pos)), replace=False)
        unit[pick[:k_lo]] = CAP_NEW + 1                    # = 3: flips
        unit[pick[k_lo:k_lo + k_hi]] = CAP_OLD             # = 4: masked by AUX
        rest = np.setdiff1d(pos, pick, assume_unique=False)
        if len(rest):
            # The compliant remainder must stay *out* of the band, or the two
            # densities contaminate each other: `below` is capped at CAP_NEW so
            # it can never land in (CAP_NEW, CAP_OLD].  `over_cap` is above
            # CAP_OLD and is supported by the aux rule, so it carries sigma >= 1
            # without being a candidate.
            below = rest[rng.random(len(rest)) < 0.20]
            unit[below] = rng.integers(1, CAP_NEW + 1, len(below)).astype(np.int16)
            over_cap = rest[rng.random(len(rest)) < 0.12]
            unit[over_cap] = rng.integers(CAP_OLD + 1, 21,
                                          len(over_cap)).astype(np.int16)

    n_groups = total // DAYS_PER_GROUP + 1
    gid = (np.arange(total, dtype=np.int32) // DAYS_PER_GROUP).astype(np.int32)
    c_line = np.argsort(code_of, kind="stable").astype(np.int32)
    cptr = np.zeros(len(plans) + 1, dtype=np.int64)
    np.cumsum(n_c, out=cptr[1:])
    inst = dict(unit=unit, amt=rng.uniform(10, 500, total).astype(np.float32),
                gid=gid, code=code_of, c_ptr=cptr, c_line=c_line,
                n_l=int(total), n_g=int(n_groups))
    override = rng.random(n_groups) < OVERRIDE_P
    store = C.Store(inst, override, build_index=True)
    # maintained support multiplicity of the current verdict, one byte a line:
    # the moved rule at its old threshold, the standing stricter one, both
    # suppressed where the group carries an override (the moved cap) -- the
    # state the mask reads instead of re-evaluating the disjunction.
    ov = override[store.gid]
    sigma = ((store.unit > CAP_OLD) & ~ov).astype(np.int8)
    sigma += (store.unit > AUX_CAP).astype(np.int8)
    # The override conjunct of Thm. 3 is folded into the same byte, as -1: a line
    # whose moved rule the override suppresses can never flip, and carrying that
    # as a sentinel keeps the mask a single gather rather than a gather plus two
    # levels of indirection through gid.
    mask_state = np.where(ov, np.int8(-1), sigma).astype(np.int8)
    return store, mask_state, n_groups


# ------------------------------------------------------------------ pipeline
S_STAR = 1 if CAP_NEW > CAP_OLD else 0


def stage_scan(store, code):
    """Path R: one contiguous pass, both states judged.  Two passes would be the
    easy way and would inflate R by 2x -- the accident that makes an index look
    good."""
    lo, hi = store.cptr[code], store.cptr[code + 1]
    v = store.unit_c[lo:hi]
    m = (v > CAP_OLD) != (v > CAP_NEW)
    if not m.any():
        return np.empty(0, np.int32)
    return store.cline[lo:hi][m].astype(np.int32)


def stage_gather(store, cand):
    """Path B: the band members themselves.  `cand` is passed in because the
    decision already paid for the probe -- charging twice for knowing what it is
    about to do is the mistake _band_cap_pair documents."""
    if len(cand) == 0:
        return np.empty(0, np.int32)
    v = store.unit[cand]
    m = (v > CAP_OLD) != (v > CAP_NEW)
    return cand[m].astype(np.int32)


def stage_mask(store, sigma, lids):
    """Thm. 3: flip iff sigma == s*.  One gather against maintained state -- the
    override conjunct rides in the same byte as -1."""
    if len(lids) == 0:
        return np.empty(0, np.int32)
    ms = sigma[lids]
    keep = ms == S_STAR
    return lids[keep].astype(np.int32)


def stage_emit(store, flips, overlay):
    """Dedup, then absorb into the overlay.  Dedup inside a batch is a bitmask
    test per identifier, not a sort: the flips of one correction are distinct by
    construction, so what an implementation pays is the test that keeps them from
    being emitted twice across corrections."""
    if len(flips) == 0:
        return 0
    fresh = ~overlay[flips]
    overlay[flips] = True
    return int(np.count_nonzero(fresh))


def run_R(store, sigma, code, overlay):
    cand = stage_scan(store, code)                 # execute
    flips = stage_mask(store, sigma, cand)         # mask
    return stage_emit(store, flips, overlay), len(cand), 0.0


def run_B(store, sigma, code, overlay, cand=None):
    probe = 0.0
    if cand is None:
        cand = store.band_u(code, CAP_NEW, CAP_OLD)   # probe
    flips = stage_gather(store, cand)                 # execute
    flips = stage_mask(store, sigma, flips)           # mask
    return stage_emit(store, flips, overlay), len(cand), probe


def ground_truth(store, code):
    """Full recomputation of the disjunction on both sides -- the expensive way,
    paid outside every timing."""
    lo, hi = store.cptr[code], store.cptr[code + 1]
    v = store.unit[store.cline[lo:hi]]
    lid = store.cline[lo:hi]
    ov = store.override[store.gid[lid]]
    old = ((v > CAP_OLD) & ~ov) | (v > AUX_CAP)
    new = ((v > CAP_NEW) & ~ov) | (v > AUX_CAP)
    return lid[old != new].astype(np.int32)


def calib():
    ref = np.arange(1 << 21, dtype=np.int64)
    v = []
    for _ in range(20):
        t0 = time.perf_counter()
        np.count_nonzero(ref >= 12345)
        v.append(time.perf_counter() - t0)
    return float(np.median(v))


def block(fns, reps):
    """Round-robin, so one GC pause cannot land entirely on one arm.  Returns
    the samples, because at the largest scope the spread exceeds the difference
    between the arms and a bare median would hide that."""
    out = {k: [] for k in fns}
    for _ in range(2):
        for f in fns.values():
            f()
    for _ in range(reps):
        for k, f in fns.items():
            t0 = time.perf_counter()
            f()
            out[k].append((time.perf_counter() - t0) * 1e6)
    return {k: np.asarray(v) for k, v in out.items()}


def med(a):
    return float(np.median(a))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--out", default=os.path.join(OUT, "masked_pipeline.json"))
    a = ap.parse_args()

    plans = [(tag, n, d) for tag, n in NS for d in DS]
    t0 = time.time()
    store, sigma, n_g = build(plans)
    print("store: %d codes, %d lines, %d groups, index %.1fs, %.1f MB, "
          "sigma kept as %s" % (len(plans), store.n_l, n_g, store.index_seconds,
                                store.index_bytes / 1e6, sigma.dtype),
          flush=True)
    ovh = np.zeros(store.n_l, dtype=bool)

    # one pass over every cell before any of them is timed
    for code in range(len(plans)):
        run_R(store, sigma, code, ovh)
        run_B(store, sigma, code, ovh)
        store.band_u(code, CAP_NEW, CAP_OLD)

    rows = []
    for code, (tag, n, d) in enumerate(plans):
        gt = ground_truth(store, code)
        cand = store.band_u(code, CAP_NEW, CAP_OLD)
        k = int(len(cand))
        n_scope = int(store.scope_len(code))

        # kernel-only arms, for the delta the pipeline adds
        def kern_R():
            stage_scan(store, code)

        def kern_B():
            stage_gather(store, cand)

        def mask_R():
            stage_mask(store, sigma, stage_scan(store, code))

        def mask_B():
            stage_mask(store, sigma, stage_gather(store, cand))

        def routed():
            c = store.band_u(code, CAP_NEW, CAP_OLD)
            if k + DP < KAPPA * n_scope:
                return run_B(store, sigma, code, ovh, c)
            return run_R(store, sigma, code, ovh)

        t = block({
            "R": lambda: run_R(store, sigma, code, ovh),
            "B": lambda: run_B(store, sigma, code, ovh, cand),
            "Q": lambda: store.band_u(code, CAP_NEW, CAP_OLD),
            "kR": kern_R,
            "kB": kern_B,
            "mR": mask_R,
            "mB": mask_B,
            "rt": routed,
        }, a.reps)


        emitted, k_seen, _ = run_R(store, sigma, code, ovh)
        same = bool(np.array_equal(np.sort(ground_truth(store, code)),
                                   np.sort(stage_mask(store, sigma,
                                                      stage_scan(store, code)))))
        mR, mB, mQ = med(t["R"]), med(t["B"]), med(t["Q"])
        pred = bool(k + DP < KAPPA * n_scope)
        meas = bool(mB < mR)
        # A routed call must cost the probe plus the path it picks -- eq. (12)
        # needs k, so the probe is paid on either branch.  The separately timed
        # arm is kept as a check, not as the reported number: where it comes in
        # below probe + path (two cells at the largest scope) the allocator's
        # state, not the policy, is what was measured.
        routed = mQ + (mB if pred else mR)
        r = dict(tag=tag, n=n_scope, k=k, dens=k / max(n_scope, 1),
                 tR=mR, tB=mB, tQ=mQ, tRouted=routed,
                 tRouted_meas=med(t["rt"]),
                 tR_lo=float(np.percentile(t["R"], 10)),
                 tR_hi=float(np.percentile(t["R"], 90)),
                 tB_lo=float(np.percentile(t["B"], 10)),
                 tB_hi=float(np.percentile(t["B"], 90)),
                 kern_R=med(t["kR"]), kern_B=med(t["kB"]),
                 ratio=mB / mR, ratio_kern=med(t["kB"]) / med(t["kR"]),
                 ratio_routed=routed / mR,
                 pred_band=pred, meas_band=meas, agree=bool(pred == meas),
                 mask_us=med(t["mR"]) - med(t["kR"]),
                 mask_B_us=med(t["mB"]) - med(t["kB"]),
                 emit_us=mR - med(t["mR"]), emit_B_us=mB - med(t["mB"]),
                 kappa_eff=((mR / max(n_scope, 1)) / (mB / max(k, 1))),
                 flip_count=len(gt), same=same)
        rows.append(r)
        print("%-6s n %7d  k %7d  d %.3f | R %8.1f [%6.1f-%6.1f]  B %8.1f "
              "[%6.1f-%6.1f]  Q %5.1f | routed %8.1f = %.3fx | B/R %.3f "
              "(kernel %.3f, kappa_eff %.2f, mask %+6.1f/%+6.1f) | %s %s"
              % (r["tag"], r["n"], r["k"], r["dens"], r["tR"], r["tR_lo"],
                 r["tR_hi"], r["tB"], r["tB_lo"], r["tB_hi"], r["tQ"],
                 r["tRouted"], r["ratio_routed"], r["ratio"], r["ratio_kern"],
                 r["kappa_eff"], r["mask_us"], r["mask_B_us"],
                 "pred-band" if r["pred_band"] else "pred-scan",
                 "ok" if r["same"] else "MISMATCH"), flush=True)

    # ---- the two numbers the paper needs --------------------------------
    pick = lambda tag, d: min((r for r in rows if r["tag"] == tag),
                              key=lambda r: abs(r["dens"] - d))
    cell = pick("median", 0.183)
    cell_lo = pick("p5", 0.183)
    print()
    print("THE CELL: n = %d (published median scope), d = 0.183, k = %d"
          % (cell["n"], cell["k"]))
    print("  path R (scan),      pipeline: %8.1f us   bare kernel: %8.1f"
          % (cell["tR"], cell["kern_R"]))
    print("  path B (band),      pipeline: %8.1f us   bare kernel: %8.1f"
          % (cell["tB"], cell["kern_B"]))
    print("  probe: %6.2f us   mask: %+6.1f us on the scan, %+6.1f on the band"
          % (cell["tQ"], cell["mask_us"], cell["mask_B_us"]))
    print("  routed (eq. 12):    %8.1f us   -> %.3f x the scan"
          % (cell["tRouted"], cell["ratio_routed"]))
    print("  kappa implied by the pipeline here: %.3f (per-row scan cost over"
          " per-candidate band cost)" % cell["kappa_eff"])
    print("  band/scan ratio: %.3f in the pipeline, %.3f on the bare kernel"
          % (cell["ratio"], cell["ratio_kern"]))
    print()
    print("the same pipeline at the low end, n = %d:" % cell_lo["n"])
    print("  R %8.1f  B %8.1f  Q %6.2f  routed %8.1f us -> %.3f x the scan"
          % (cell_lo["tR"], cell_lo["tB"], cell_lo["tQ"], cell_lo["tRouted"],
             cell_lo["ratio_routed"]))
    print()
    print("the four cells at the measured density 0.183, in one column:")
    for r in rows:
        if abs(r["dens"] - 0.183) < 0.01:
            print("  n %7d  R %8.1f  B %8.1f  routed %8.1f  -> %.3fx the scan"
                  % (r["n"], r["tR"], r["tB"], r["tRouted"], r["ratio_routed"]))
    print()
    print("criterion vs stopwatch over the %d cells: %d agree"
          % (len(rows), sum(1 for r in rows if r["agree"])))
    at0183 = [r for r in rows if abs(r["dens"] - 0.183) < 0.01]
    print("   at the measured density 0.183: %d of %d"
          % (sum(1 for r in at0183 if r["agree"]), len(at0183)))

    res = dict(reps=a.reps, cap=(CAP_OLD, CAP_NEW), aux_cap=AUX_CAP,
               days_per_group=DAYS_PER_GROUP, override_p=OVERRIDE_P,
               tuple=TUPLE_NOTE, cells=len(rows), rows=rows,
               agree=int(sum(1 for r in rows if r["agree"])),
               delta_complete=bool(all(r["same"] for r in rows)))
    os.makedirs(OUT, exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1, default=float)
    print("\nwall %.0fs, wrote %s" % (time.time() - t0, a.out))


if __name__ == "__main__":
    main()
