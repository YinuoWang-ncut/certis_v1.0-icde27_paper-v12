# Where each claim comes from

One row per claim a reviewer could try to falsify. The `check` column is the honest
part:

* **assert** — `reproduce.py` compares the produced file against `expected.json`
  and exits non-zero on any mismatch. Host-free.
* **record** — a property of the machine. Printed beside the paper's value, never
  asserted. See the `recorded` section of `expected.json`.
* **†** — needs the corpus: the 27 CMS releases (`data/fetch.py`), or the ~10 GB
  CMS utilisation release, which is not redistributed.

`python reproduce.py --no-data` covers every row without a dagger.

Section letters are the v21 draft's.  In the v5 (EAB) manuscript the
workload paragraph is §II-B, the boundary arithmetic is §V-D, the
head-to-head table is §V-B (Tab. V) and the six bare layouts are §V-C
(Tab. VI).  The script and output columns are unchanged and are what the
check reads; renumbering the § column is a 30-minute job, not a
correctness one.

| § | claim | script | output | check |
|---|---|---|---|---|
| III, Thm. 1–5 | the eleven statements, one witness each | `tests/test_theorems.py` | stdout: `11 / 11 passed` | assert (exit status) |
| IV-B | degree, end-dating, modifier distribution | `exp/degree.py` | `exp/degree.json` | assert |
| IV-B | published delta vs reconstruction; 4,249 / 4,146; zero disappeared pairs; 14 end-dated deletions; 5 of 7 indicator flips; 31 unsigned revisions | `exp/delta.py` | `exp/delta.json` | assert |
| IV-B | relative regimes (b)/(c), semi-synthetic | `exp/regime_bc.py` | `exp/regime_bc.json` | assert |
| IV-D | `kappa = 0.4414`, `n_0 = 451.3` rows from four fitted constants | `exp/boundary.py` | `exp/boundary.json` | assert |
| IV-D | the second accounting, `kappa = 0.0696` (read 0.762 before the predicate fix; the paper prints neither) | `exp/cost_model.py` | `exp/cost_model.json` | record |
| V-E | `Delta p` and the decision line solved for `a_d` | `exp/n0_impl/dline.py` | `exp/n0_impl/dline.json` | assert |
| V-E, Tab. VI | the six bare layouts: `kappa` and `k*` per layout | `exp/n0_holdout/analyze.py` | `exp/n0_holdout/n0_holdout_summary.json` | assert |
| V-E | six probe rows in the units of (6) | `exp/n0_robust/probe_rows.py` | `exp/n0_robust/probe_rows.json` | assert |
| V-E | `kappa` against \|D\|: one run per size, 0.034 / 0.0333 / 0.0270 | `exp/n0_impl/scale.py` | `exp/n0_impl/scale.json` | record |
| V-E | `kappa` over 50 fresh processes per cell: medians 0.0337, 0.0311, 0.0276; `c_R` 0.258/0.258/0.266; `c_B` 7.62/8.34/9.48 | `exp/n0_impl/scale_reps.py` | `exp/n0_impl/scale_reps.json` | record |
| V-E | the seven end-to-end re-runs, span 0.26–0.46 | `exp/fit_kappa_runs.py` | `exp/kappa_runs.json` | folded into `exp/boundary.json`, span printed not asserted |
| V-B, Tab. V | path R on the 436-row instance the engines share: 9.5 µs warm, 10.5 µs cold; the band end to end 13.7 / 15.4 µs, so 1.44x | `exp/path_r_h2h/` | `exp/path_r_h2h/path_r_h2h.json` | record |
| V-B, Tab. V | the same scope on a second microarchitecture (Zen4 mobile, 6 cores): 16.45 / 22.25 µs, 1.35x from the two medians and 1.37x as the median of three paired runs, 1.43x cold against 1.46, both paths 1.73x / 1.62x in level | `exp/cross_machine.py --quick --tag box2` x3, then `--merge box2` | `exp/cross_machine_box2.txt` | record — `--merge` recomputes the aggregate from `cross_machine_box2-r*.json` and refuses when they are absent; that box returned only its run summary, so the three per-run files are not shipped |
| V-B, Tab. V | the reference head-to-head, divided by that measured denominator | `exp/ivm.py`, `exp/ivm_h2h/`, `exp/java/CountOracle.java` | `exp/ivm.json`, `exp/ivm_h2h/ivm_h2h.json` | record |
| V-D | 116 moves, 98 empty bands, the cap-table bounds | `exp/cheap.py` | `exp/cheap.json` | assert |
| V-F | a verdict for all 116 observed moves; 13 certified empty | `exp/utilization.py` | `exp/utilization.json` | record — the 10 GB input is not shipped |
| V-F | the tightest slack per case, so the thirteen re-derive | `exp/empty_cases.py` | `exp/empty_cases.csv` | † |
| V-D | the fetch/scan ratio, 17.2, machine-independent part only | `exp/rank_probe.py` | `exp/rank_probe.json` | record |
| V-D | the 600 corrections under both protocols: `kappa = 0.214` (alternating) against `0.441` (recorded); `n_0 = 959` and `717`; `Delta p = 199` and `316`; none faster down the band in all 23, 362 slower in all 23, 28 protocol-flipped, agreement 81.0\% against 77.3\% | `exp/alt600.py` | `exp/out/alt600.json` | assert |
| V-D | the two protocols read the same 600 corrections (`stream_identical`) | `exp/alt600.py` | `exp/out/alt600.json` | assert |
| V-E | band density ceiling from two published columns: 426 in-regime moves, median ceiling 0.183, quartiles 0.042/0.401; 193 admitted, 233 excluded on density | `exp/realband.py` | `exp/realband.json` | † |
| V-E, Tab. V | the criterion against the stopwatch: 24 cells, 19 agree; the confusion matrix 5/3/2/14, 5/9 within 20% of a tie, 14/15 beyond, and no false admission beyond the tie band | `exp/bigscope.py` | `exp/bigscope.json` | record (needs the prototype) |
| V-E | the masked pipeline at the published sizes: 1.30 / 0.96 / 0.53 / 0.52 times the scan at d=0.183, Delta-complete on all four | `exp/masked_pipeline.py` | `exp/out/masked_pipeline.json` | assert |
| V-E | the criterion against the stopwatch on 24 cells at published scale: 19 agree, 44,606 rows at 0.183 gives 107 against 184 us | `exp/bigscope.py` | `exp/bigscope.json` | record (needs the prototype) |
| V-B | the second microarchitecture: box 1 at 9.5/13.7 $\mu$s and box 2 at 16.45/22.25, ratios 1.44 and 1.35; box 2 run 1 is 1.3921$\times$ run 3 in level but only 1.0244$\times$ in ratio | `exp/cross_machine.py --quick --tag box2` | `exp/cross_machine/{box1,box2-r1,box2-r2,box2-r3,summary}.json` | record |
| V-E | verification versus scan on the same 600 corrections: 0.90 at the median, 1.04 in aggregate, 410 of 600; probe 6.4 against a 14.6 us scan | `exp/fullpath_band_vs_scan.py` | `exp/fullpath.json` | record (needs the prototype) |
| V-A | end-to-end ordering and `Delta`-completeness on five policies | `exp/e2e_repro.py` | `exp/e2e_repro.json` | record (needs the prototype) |

## What the artifact does not contain

1. **The corpus.** 27 CMS files, ~250 MB, fetched and SHA-256-verified by
   `data/fetch.py` against `data/manifest.csv`. The PTP and MUE tables carry CPT
   content that is AMA property, so they are not redistributed.
2. **The ~10 GB utilisation release.** `exp/utilization.py` and
   `exp/empty_cases.py` read it; `exp/utilization.json` is the reference run over
   its 9.78M rows, shipped in its place.
3. **Nothing, for the tables.** `certis.py` ships at the tree root and the
   prototype that drives it ships under `exp/prototype/` (`w12/run_w12.py`,
   `w8/`), so Table II, Table III and the phase split of Sect. V-E are
   re-timable from a clean checkout: `exp/e2e_repro.py`,
   `exp/fullpath_band_vs_scan.py`, `exp/bigscope.py` and
   `exp/masked_pipeline.py` find the prototype without any environment
   variable. `masked_pipeline.py` is the pipeline cell of Sect. V-A: it runs
   all five stages -- mask, dedup, overlay, selector -- at the four published
   per-code scope sizes, which is what makes Table II (401 rows) and the
   six-density sweep (up to 412,875) points on one curve instead of two
   objects. It prints 1.29x / 0.95x / 0.54x / 0.52-0.63x the scan; the first
   three repeat to 2%, the last is given as an interval for that reason. What is not shipped is the ingestion
   path that built the corpus store from the raw CMS downloads -- it is not
   needed, because the stores those three scripts build are synthetic and
   self-contained.
