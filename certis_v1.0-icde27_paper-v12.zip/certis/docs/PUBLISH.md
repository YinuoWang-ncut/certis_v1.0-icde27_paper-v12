# Publishing this artifact for ICDE 2027

The manuscript (v10) points at `\artifactaddress`. Until that substitution is
made, the PDF prints a red `[address not yet substituted]` and the paper has no
retrievable artifact — which the ICDE 2027 call makes disqualifying for the
Experiment, Analysis and Benchmark category, with no exceptions.

Everything below is on this machine already. The tree is committed and tagged
`v1.0-icde27`, the archive built from that tag passes `reproduce.py --no-data`
from a clean extraction, and the only thing missing is a public URL.

## 0. What the URL must point at, and what it must not

The paper says *"the release is the git tree tagged `v1.0-icde27`"*. A fixed
archive cannot satisfy that sentence: a `.zip` has no tag, no history, and no
way for a reader to check out the bytes that were reviewed. So the address is
the **repository** or the **tagged tree**, or a **DOI** of that release — never
a `.zip`/`.tar`, and never a link that needs a login.

`tools/set_url.py` refuses archive URLs for exactly this reason, so the mistake
cannot reach the PDF.

| what you paste into `set_url.py` | what a reviewer sees |
|---|---|
| `https://github.com/<you>/certis` | the repository, tag selectable in the branch menu |
| `https://github.com/<you>/certis/tree/v1.0-icde27` | exactly the reviewed tree |
| `https://doi.org/10.5281/zenodo.<id>` | permanent record of that tree |

The tag URL is the safest of the three: it lands on the reviewed bytes and
survives later commits to `main`.

An archive is still worth publishing as an **extra mirror** — reviewers behind
a firewall, or artifact chairs who want one download — but it is not the
address, and nothing in the paper should claim it is.

## 1. Push the commit and the tag

Already done locally: commit `619ae0e` and annotated tag `v1.0-icde27`. What
remains is a remote.

```bash
cd release/certis

git remote add origin https://github.com/<you>/certis.git
git push -u origin main
git push origin v1.0-icde27
```

Check that the tag is on the remote before filling the URL in:
`git ls-remote --tags origin` should list `refs/tags/v1.0-icde27`.

## 2. Archive it and get a DOI (recommended, not required)

Zenodo can mint a DOI from the tag and `.zenodo.json` is already in the tree:

1. Sign in to zenodo.org with GitHub, enable the repository under *Settings → GitHub*.
2. Publish a release from tag `v1.0-icde27`.
3. Copy the DOI badge URL.

A DOI survives repository deletion and is what an artifact evaluator expects;
a bare GitHub URL is acceptable under the call (`"standard, openly accessible
file sharing services"`) but the DOI is better.

## 3. Put the address in the paper

```bash
cd ../..                       # back to ICDE2028_EAB_V2
python tools/set_url.py https://github.com/<you>/certis/tree/v1.0-icde27
python tools/set_url.py --check     # must exit 0
python build.py                     # prints the pages and the overfull count
```

`set_url.py` rewrites `\artifactslug` and raises `\artifactsettrue`, so the PDF
prints a live link instead of the red slot. `--check` exits non-zero while the
slot is unfilled: wire it into whatever builds the submission PDF and the
mistake becomes impossible rather than merely unlikely.

If the DOI is preferred over the repository URL, pass the DOI URL instead —
the script does not care which.

## 4. Verify before submitting

```bash
cd release/certis
python reproduce.py --no-data      # must end with "all assertions hold", exit 0
```

That run covers the eleven theorem witnesses, the boundary arithmetic, the six
bare layouts, the probe rows, the decision line, and the two-protocol replay of
Sect. V-D — every number the paper prints that does not need the corpus. With
the 27 CMS files fetched (`python data/fetch.py`), plain `python reproduce.py`
adds the corpus blocks.

Three blocks are printed rather than asserted, because they are timings:
`exp/e2e_repro.py`, `exp/fullpath_band_vs_scan.py` and `exp/bigscope.py`. They
need no environment variable — they find the prototype under `exp/prototype/`
on their own — and each takes about a minute.

## 5. What is not in the tree, and why

* **The 27 CMS releases (~250 MB).** CPT content is AMA property, so they are
  fetched and SHA-256-verified by `data/fetch.py` against `data/manifest.csv`
  rather than redistributed. The manifest is the guarantee, not the bytes.
* **The ~10 GB utilisation release.** `exp/utilization.json` is the reference
  run over its 9.78M rows, shipped in place of the file.
* **The ingest path from raw CMS downloads to the corpus store.** Not needed:
  every store the shipped scripts build is synthetic and self-contained.

## 6. Sanity checks already done here

| check | result |
|---|---|
| `python reproduce.py --no-data` | exit 0, "all assertions hold" |
| every script the Artifact paragraph names | present under `exp/` |
| no absolute path or drive letter in any shipped script | confirmed by grep |
| `exp/alt600.py` from the shipped records | κ 0.214 / 0.441, n₀ 959 / 717 — matches the paper |
| `reproduce.py --no-data` from a clean extraction of the v12 archive | exit 0, "all assertions hold", 10 of 10 assert blocks ok |
| archive built with `git archive v1.0-icde27` | no `_repro.log`, no `.git`, 388 entries, 2.0 MB |
| `set_url.py` with a `.zip` URL | exits 1 with an explanation, so an archive cannot become the address |
| tree size, excluding `.git` | ~6 MB plus 2.2 MB of run records |
